Caaaaarbs
=============

Caaaaarbs is a stupid joke Chrome extension about my editor, Owen Thomas, who follows the Paleo diet. I joked that this was how he sees the Internet. 

<img src="http://otakujournalist.com/wp-content/uploads/2014/08/Screen-Shot-2014-08-19-at-1.58.31-PM.png" />

Acknowledgements
=============

Caaaaarbs is nearly 100% cloned from Steven Frank's <a href="https://github.com/panicsteve/cloud-to-butt">Cloud To Butt</a>, with his permission. Thanks for helping me do something even stupider! 
